package ie.app.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

import ie.app.activities.Base;
import ie.app.models.Donation;
import io.realm.Realm;
import io.realm.RealmConfiguration;
import io.realm.RealmResults;


public class DBManager {

	public Realm realmDatabase;

	public DBManager(Context context) {
		Realm.init(context);

		RealmConfiguration config = new RealmConfiguration.Builder()
				.name("donation.realm")
				.schemaVersion(1)
				.build();

		Realm.setDefaultConfiguration(config);
	}

	public void open() throws SQLException {
		realmDatabase = Realm.getDefaultInstance();
	}

	public void close() {
		realmDatabase.close();
	}

	public void add(Donation d) {
		realmDatabase.beginTransaction();
		realmDatabase.copyToRealm(d);
		realmDatabase.commitTransaction();
	}

	public List<Donation> getAll() {
		RealmResults<Donation> result = realmDatabase.where(Donation.class)
													 .findAll();
		return result.subList(0,result.size());
	}

	public Donation get(String id) {
		return realmDatabase.where(Donation.class)
				.equalTo("id",id)
				.findAll()
				.first();
	}

	public void setTotalDonated(Base base) {
		base.app.totalDonated = realmDatabase.where(Donation.class)
											 .findAll()
											 .sum("amount")
											 .intValue();
	}

	public void reset() {
		realmDatabase.beginTransaction();
		realmDatabase.where(Donation.class)
					 .findAll()
					 .deleteAllFromRealm();
		realmDatabase.commitTransaction();
	}
}
