package ie.app.activities;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import ie.app.R;


public class Register extends Activity {
	private boolean mIsBackButtonPressed;
	private SharedPreferences settings;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_register);
		
		settings = getSharedPreferences("loginPrefs", 0);
	}

	public void register(View v) {
		CharSequence username = ((TextView) findViewById(R.id.registerUsername))
				.getText();
		CharSequence password = ((TextView) findViewById(R.id.registerPassword))
				.getText();

		if (username.length() <= 0 || password.length() <= 0)
			Toast.makeText(this, "You must enter an email & password",
					Toast.LENGTH_SHORT).show();
		else if (!mIsBackButtonPressed) {
			// Update logged in preferences
			SharedPreferences.Editor editor = settings.edit();
			editor.putBoolean("loggedin", true);
			editor.putString("username", username.toString());
			editor.putString("password", password.toString());
			editor.commit();
			// start the home screen if the back button wasn't pressed already
			startHomeScreen();
			this.finish(); // destroy the Register Activity
		}
	}
	
	@Override
	public void onBackPressed() {
		// set the flag to true so the next activity won't start up
		mIsBackButtonPressed = true;
		super.onBackPressed();
	}
	
	private void startHomeScreen() {
		Intent intent = new Intent(Register.this, Donate.class);
		Register.this.startActivity(intent);
	}
}
