package ie.app.activities;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import ie.app.R;

public class Login extends Activity {

	// used to know if the back button was pressed in the splash screen activity
	// and avoid opening the next activity
	private boolean mIsBackButtonPressed;
	private SharedPreferences settings;

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	
		settings = getSharedPreferences("loginPrefs", 0);
		if (settings.getBoolean("loggedin", false))
			/* The user has already logged in, so start the Home Screen */
			startHomeScreen();
		
		setContentView(R.layout.activity_login);

	}

	public void register(View v) {
		startActivity (new Intent(this, Register.class));
	}
	
	private void startHomeScreen() {
		Intent intent = new Intent(Login.this, Donate.class);
		Login.this.startActivity(intent);
	}
	
	@Override
	public void onBackPressed() {
		// set the flag to true so the next activity won't start up
		mIsBackButtonPressed = true;
		super.onBackPressed();
	}

	
	public void login(View v) {

		CharSequence username = ((TextView) findViewById(R.id.loginUsername))
				.getText();
		CharSequence password = ((TextView) findViewById(R.id.loginPassword))
				.getText();

		String validUsername = settings.getString("username", "");
		String validPassword = settings.getString("password", "");
		
		if (username.length() <= 0 || password.length() <= 0)
			Toast.makeText(this, "You must enter an email & password",
					Toast.LENGTH_SHORT).show();
		else if (!username.toString().matches(validUsername)
				|| !password.toString().matches(validPassword))
			Toast.makeText(this, "Unable to validate your email & password",
					Toast.LENGTH_SHORT).show();
		else if (!mIsBackButtonPressed) {
			// Validate User with Server Here

			// Update logged in preferences
			SharedPreferences.Editor editor = settings.edit();
			editor.putBoolean("loggedin", true);
			editor.commit();
			// start the home screen if the back button wasn't pressed already
			startHomeScreen();
			this.finish(); // destroy the Login Activity
		}
	}
}
