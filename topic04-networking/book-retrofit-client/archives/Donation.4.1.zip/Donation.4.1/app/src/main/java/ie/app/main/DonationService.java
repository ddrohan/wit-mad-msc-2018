package ie.app.main;

import java.util.List;

import ie.app.models.Donation;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;

public interface DonationService
{
    @GET("/donations")
    Call<List<Donation>> getAllDonations();

    @GET("/donations/{id}")
    Call<List<Donation>> getDonation(@Path("id") String id);

    @DELETE("/donations/{id}")
    Call<Donation> deleteDonation(@Path("id") String id);

    @POST("/donations")
    Call<Donation> createDonation(@Body Donation donation);

    @PUT("/donations/{id}/votes")
    Call<Donation> upVoteDonation(@Path("id") String id,
                                  @Body Donation donation);
}
