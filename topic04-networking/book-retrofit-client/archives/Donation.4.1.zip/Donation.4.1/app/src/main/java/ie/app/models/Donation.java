package ie.app.models;

public class Donation
{
    public String   _id;
    public int      amount;
    public String   paymenttype;
    public int      upvotes;
    public double   latitude;
    public double   longitude;


    public Donation (int amount, String paymenttype,
                     int upvotes, double lat, double lng)
    {
        this.amount = amount;
        this.paymenttype = paymenttype;
        this.upvotes = upvotes;
        this.latitude = lat;
        this.longitude = lng;
    }


    public String toString()
    {
        return _id + ", " + amount + ", " + paymenttype + ", " + upvotes + ", " + latitude + ", " + longitude;
    }
}