package ie.cmfbi.models;

public class Coords {
    public double latitude;
    public double longitude;
}
