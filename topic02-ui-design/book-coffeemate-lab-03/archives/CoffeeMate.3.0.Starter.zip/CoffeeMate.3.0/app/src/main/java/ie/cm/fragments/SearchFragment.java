package ie.cm.fragments;

import android.content.Context;
import android.os.Bundle;

public class SearchFragment extends CoffeeFragment {

	@Override
	public void onAttach(Context c) {
		super.onAttach(c);
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
	}

	@Override
	public void onStart() {
		super.onStart();
	}
}