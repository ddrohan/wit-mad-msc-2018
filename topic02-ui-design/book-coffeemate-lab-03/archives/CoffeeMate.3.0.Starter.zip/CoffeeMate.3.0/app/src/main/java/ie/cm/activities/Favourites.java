package ie.cm.activities;

import ie.cm.R;
import ie.cm.fragments.CoffeeFragment;

import android.os.Bundle;
import android.widget.TextView;

public class Favourites extends Base {
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.favourites);
	}
	
}
